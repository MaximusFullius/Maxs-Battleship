import java.text.ParseException;
import java.util.Locale;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class Game {
    public static int turnCountP1;
    public static int turnCountP2;
    public static int turnCountTotal;
    protected static final String AdminPass = "1234";

    public static void Help(char chMode, char chDifficulty){
        System.out.println("-------------------- BEGINNING OF HELP SECTION --------------------");
        System.out.println("This is the game board. There are enemy ships in this board, but they are currently hidden in" +
                "\na fog of war. The objective of the game are to find and sink all the enemy ships on this board before " +
                "\nthe enemy sinks all of yours...");

        if (chMode == 'S'){
            System.out.println("\nSince you are playing in single player mode, however, and AI hasn't been implemented" +
                    "\ninto this game yet, you don't need to worry about the enemy destroying any of your ships." +
                    "\nYou only need to focus on finding the enemy ships.");
        }

        System.out.println("\nEvery cell on this board has a coordinate, as marked by the vertical and horizontal number" +
                "\naxes on the sides of the board. On each turn, you may either enter a coordinate in the format of a " +
                "\nnumber, a comma and another number with no spaces (like this #,#), or enter a power.");

        System.out.println("\nIn order to sink a ship, you must damage every cell of the ship. Different ships have " +
                "\ndifferent lengths and thus different numbers of cells to destroy before they are fully sunk." +
                "\nDestroyers are 2 cells long, Cruisers are 3 cells long, Battleships are 4 cells long, and" +
                "\nCarriers are 5 cells long.\n");

        switch(chDifficulty){
            case 'B':
                System.out.println("Beginner boards have one Destroyer.\n");
                break;

            case 'I':
                System.out.println("Intermediate boards have one Destroyer, one Cruiser and one Battleship.\n");
                break;

            case 'A':
                System.out.println("Advanced boards have one Destroyer, two Cruisers, one Battleship, and one Carrier.\n");
                break;
        }

        System.out.println("There are 3 types of special powers in this game: Missiles, Submarines and Drones.");
        System.out.println("\nMissiles explode in a 3x3 cell explosion, centered at their target coordinate." +
                "\nall ship parts within the blast radius will be damaged. Any cells within the blast radius that " +
                "\ngo outside the board will not damage any ships. Type \"missile\" to deploy a missile.\n");

        System.out.println("Submarines will fire a devastating nuclear torpedo that will instantly sink any ship it hits." +
                "\nType \"submarine\" to deploy a submarine.\n");

        System.out.println("Drones will scan a random row or column of the board and tell you how many ships it sees in that row or column." +
                "\nThe drone will never scan the same row or column twice and it saves valuable time. Type \"drone\" to deploy a drone,\n");

        System.out.println("To enable debug mode, type \"ADMIN\" during the singleplayer/multiplayer selection step and enter the password. (See the readme).");
        System.out.println("-------------------- END OF HELP SECTION --------------------\n");
    }

    public static void main(String[] args){
        turnCountP1 = 0;
        turnCountP2 = 0;
        turnCountTotal = 0;
        System.out.println("~~~~~ Welcome to Battleship. Code by Maxwell Fuller ~~~~~");
        System.out.println("This is the classic game of battleship, but with a few fun twists.");
        System.out.println("You can deploy devastating torpedo submarines, spy drones or massive missiles!");
        System.out.println("You can play by yourself or with a friend on the same computer.");

        Scanner scn = new Scanner(System.in);
        boolean bModeValid = false;
        String ModeInput = "";
        String strOutput = "";
        boolean bAdmin = false;
        while (!bModeValid){
            System.out.println("\nSelect game mode. \"S\" is singleplayer. \"T\" is multiplayer: ");
            ModeInput = scn.nextLine();
            ModeInput = ModeInput.toUpperCase(Locale.ROOT);
            if (ModeInput.equals("ADMIN")){ // Toggle admin mode
                bModeValid = false;
                if (bAdmin){
                    bAdmin = false;
                    System.out.println("Administrator mode disabled.");
                }
                else{
                    int attempts = 0;
                    while (!bAdmin){
                        System.out.print("\npassword: ");
                        ModeInput = scn.nextLine();
                        if (ModeInput.equals("1234")){
                            System.out.println("Welcome, administrator.");
                            bAdmin = true;
                        }
                        else{
                            bAdmin = false;
                            System.out.println("Access Denied.");
                            attempts++;
                            if (attempts >= 3){
                                System.out.println("Password attempt limit exceeded. Terminating Program...");
                                System.exit(0);
                            }
                            else{
                                System.out.println((3-attempts) + " attempts remaining...");
                            }
                        }
                    }
                }
            }
            else{
                if (ModeInput.equals("S") || ModeInput.equals("T")){
                    strOutput = "\nInput Accepted. ";
                    switch(ModeInput){
                        case "S":
                            strOutput += "Single player mode selected.";
                            break;

                        case "T":
                            strOutput += "Multiplayer mode selected.";
                            break;
                    }
                    System.out.println(strOutput);
                    bModeValid = true;
                }
                else{
                    System.out.println("Error: Invalid input for game mode. please try again.");
                }
            }
            if (bAdmin){
                System.out.println("** Administrator mode Enabled **");
            }
        }

        boolean bDifficultyValid = false;
        String DiffInp = "";
        while(!bDifficultyValid){
            System.out.println("\nSelect board size.");
            System.out.println("\"B\" is Beginner (3x3 with 1 ship), \"I\" is Intermediate (6x6 with 3 ships), and \"A\" is Advanced (9x9 with 5 ships): ");
            DiffInp = scn.nextLine();
            DiffInp = DiffInp.toUpperCase(Locale.ROOT);
            if ((DiffInp.equals("B") || DiffInp.equals("I")) || DiffInp.equals("A")){
                strOutput = "\nInput Accepted. ";
                switch(DiffInp){
                    case "B":
                        strOutput += "Beginner-sized board (3x3, 1 ship) selected.";
                        break;

                    case "I":
                        strOutput += "Intermediate-sized board (6x6, 3 ships) selected.";
                        break;

                    case "A":
                        strOutput += "Advanced-sized board (9x9, 5 ships) selected.";
                        break;
                }
                System.out.println(strOutput);
                bDifficultyValid = true;
            }
            else{
                System.out.println("Error: Invalid input for board size. Please try again.");
            }
        }
        char chDifficulty = DiffInp.charAt(0);
        char chMode = ModeInput.charAt(0);

        Board b1 = new Board(chDifficulty, chMode);
        if (chMode == 'T'){
            System.out.println("\nGame ready to start! The game will start with P1's boards on the screen, " +
                    "so make sure P2 isn't looking at the screen at the beginning!!\nPress enter to begin...");
        }
        else{ // singleplayer mode
            System.out.println("\nGame ready to start! Press enter to begin...");
        }
        String strInput = scn.nextLine();

        Help(chMode, chDifficulty); // Always display the help section once at the beginning of the game.

        boolean bGameContinue = true;
        boolean bInputValid;
        // DO NOT RUN until while loops are completed with their exit conditions.
        if (chMode == 'S'){ // Single player mode
            turnCountTotal = 0;
            while(bGameContinue){
                //In single player, P1's grid is the only grid to print. Always show the hud in singleplayer mode.
                bInputValid = false;
                if (bAdmin){
                    System.out.println(b1.display(1, false));
                }
                else{
                    System.out.println(b1.print(1, false));
                }
                System.out.println("Turns: " + turnCountTotal);

                String[] strSplit = new String[2];
                String[] coordSplit = new String[2];
                int[] intSplit = new int[2];
                boolean bCoordsValid = false;

                while(!bInputValid){
                    System.out.println("Type your input here. Type \"help\" to see the help section:");
                    strInput = scn.nextLine();
                    // User input cleaning
                    strInput.toLowerCase(Locale.ROOT);
                    strInput.trim();
                    // User input testing
                    if (strInput.contains(",") && strInput.length() >= 8){
                        strSplit =  strInput.split(" ");
                        coordSplit = strSplit[1].split(",");
                        try{
                            intSplit[0] = Integer.parseInt(coordSplit[0]);
                            intSplit[1] = Integer.parseInt(coordSplit[1]);
                        }
                        catch (Exception e){
                            System.out.println("Input Error. Please try again.");
                            bInputValid = false;
                        }
                        //Check if the inputs are on the grid:
                        if ((intSplit[0] > 0 && intSplit[1] > 0)){
                            if (chDifficulty == 'B'){
                                bCoordsValid = (intSplit[0] <= 3 && intSplit[1] <= 3);
                            }
                            else{
                                if (chDifficulty == 'I'){
                                    bCoordsValid = (intSplit[0] <= 6 && intSplit[1] <= 6);
                                }
                                else{ // chDifficulty == 'A'
                                    bCoordsValid = (intSplit[0] <= 9 && intSplit[1] <= 9);
                                }
                            }
                        }
                        else{
                            bCoordsValid = false;
                            bInputValid = false;
                        }

                        if (bCoordsValid){
                            //FIRE
                            if (strInput.contains("fire") && strInput.length() == 8){
                                // The fire input needs at least 8 characters
                                // f i r e _ # , #
                                // 1 2 3 4 5 6 7 8

                                strOutput = b1.fire(intSplit[0]-1, intSplit[1]-1, 1, 1, false);
                                if (strOutput.equals("WIN")){
                                    bInputValid = true;
                                    bGameContinue = false;
                                    turnCountTotal += 1;
                                }
                                else{
                                    if (strOutput.equals("INVALID COORDINATES")){
                                        System.out.println(strOutput);
                                        bInputValid = false;
                                    }
                                    else{
                                        if (strOutput.contains("MISS")){
                                            strOutput.replaceAll("MISS", "");
                                        }
                                        //Always print out the results of the fire command, regardless if it's a hit or a miss.
                                        //We've already verified that the shot is somewhere on the board.
                                        System.out.println(strOutput);
                                        turnCountTotal += 1;
                                        bInputValid = true;
                                    }
                                }
                            }
                            else{
                                //MISSILE
                                if (strInput.contains("missile") && strInput.length() == 11){
                                    // The missile input needs at least 11 characters
                                    // m i s s i l e _ # ,  #
                                    // 1 2 3 4 5 6 7 8 9 10 11

                                    strOutput = b1.missile(intSplit[0]-1, intSplit[1]-1, 1, 1);
                                    if (strOutput.contains("WIN")){
                                        turnCountTotal += 1; // increment turn count
                                        bInputValid = true;
                                        bGameContinue = false;
                                        System.out.println(strOutput);
                                    }
                                    else{
                                        if (strOutput.equals("No more power points remaining. Cannot fire missile.")){
                                            System.out.println(strOutput);
                                            bInputValid = false;
                                            // Do not increment turn count.
                                        }
                                        else{ // Other message returned. Missile deployment successful
                                            System.out.println(strOutput);
                                            bInputValid = true;
                                            turnCountTotal += 1;
                                        }
                                    }
                                }
                                else{
                                    //SUBMARINE
                                    if (strInput.contains("submarine") && strInput.length() == 13){
                                        // The submarine input needs at least 13 characters
                                        // s u b m a r i n e _  #  ,  #
                                        // 1 2 3 4 5 6 7 8 9 10 11 12 13
                                        strOutput = b1.submarine(intSplit[0]-1, intSplit[1]-1, 1, 1);
                                        if (strOutput.contains("WIN")){
                                            System.out.println(strOutput); // print the Submarine's message.
                                            turnCountTotal += 1; // increment turn count
                                            bInputValid = true;
                                            bGameContinue = false;
                                        }
                                        else{
                                            if (strOutput.equals("Submarine deployment failed. Player 1 does not have enough PP to deploy a submarine.")){
                                                System.out.println(strOutput);
                                                bInputValid = false;
                                            }
                                            else{ // other submarine message
                                                System.out.println(strOutput);
                                                bInputValid = true;
                                            }
                                        }

                                    }
                                    else{ //invalid input
                                        System.out.println("Error: Invalid input. Please try again.");
                                        bInputValid = false;
                                    }
                                }
                            }
                        }
                        else{ // bCoordsValid == false
                            System.out.println("Error: Invalid Coordinates.");
                            bInputValid = false;
                            break; // break out of if-statement.
                        }
                    }
                    else{ // input does not contain a comma
                        if (strInput.equals("drone")){
                            bInputValid = true;
                            strOutput = b1.drone(1, 1);
                            System.out.println(strOutput);
                        }
                        else{
                            if (strInput.equals("help")){
                                bInputValid = false; // loop through and re-print the board without incrementing the turns.
                                Help(chMode, chDifficulty);
                            }
                            else{ //invalid input
                                bInputValid = false;
                                System.out.println("Error: Invalid input. Please try again.");
                            }
                        }
                    }
                }
                System.out.println("Press enter to continue...");
                strInput = scn.nextLine();
            }
            // END GAME SEQUENCE - Single player
            System.out.println("Total Turns: " + turnCountTotal);
            System.out.println("Thank you for playing! Goodbye.");
        }
        else{
            if (chMode == 'T'){ // Multiplayer mode.
                boolean bP1turn = true; // true means its p1s turn; false means its p2s turn.
                turnCountP1 = 0;
                turnCountP2 = 0;
                turnCountTotal = 0;

                while(bGameContinue){
                    //In multiplayer, display p2's (hidden) board on top on p1's turn, and p1's (hidden) board on top on p2's turn.
                    // Always display the player's board (unhidden) at the bottom so that the players can see the status of their ships.
                    bInputValid = false;
                    //
                    if (bAdmin){
                        // Reveal all ships in all turns during admin mode.
                        if (bP1turn) { // Player 1's turn
                            System.out.println("[ENEMY'S SHIPS]");
                            System.out.println(b1.display(2, true));
                            System.out.println("---------------------------------"); // Dividing line
                            System.out.println("[YOUR SHIPS]");
                            System.out.println(b1.display(1, false));
                        }
                        else { // Player 2's turn
                            System.out.println("[ENEMY'S SHIPS]");
                            System.out.println(b1.display(1, true));
                            System.out.println("---------------------------------"); // Dividing line
                            System.out.println("[YOUR SHIPS]");
                            System.out.println(b1.display(2, false));
                        }
                    }
                    else{ // normal mode
                        if (bP1turn) { // P1's turn
                            System.out.println("[ENEMY'S SHIPS]");
                            System.out.println(b1.print(2, true)); // Hide unhit cells in P2's board.
                            System.out.println("---------------------------------"); // Dividing line between boards
                            System.out.println("[YOUR SHIPS]");
                            System.out.println(b1.display(1, false)); // Show all of P1's ships on their turn.
                        }
                        else { // P2's turn
                            System.out.println("[ENEMY'S SHIPS]");
                            System.out.println(b1.print(1, true));
                            System.out.println("---------------------------------"); // Dividing line
                            System.out.println("[YOUR SHIPS]");
                            System.out.println(b1.display(2, false));
                        }
                    }
                    turnCountTotal = turnCountP1 + turnCountP2; // update turn count total every turn
                    System.out.println("Turns: " + turnCountTotal);

                    String[] strSplit = new String[2];
                    String[] coordSplit = new String[2];
                    int[] intSplit = new int[2];
                    boolean bCoordsValid = false;
                    boolean bWinner; // If winner is true, p1 won. Otherwise, P2 won.

                    while(!bInputValid){
                        //Multiplayer input validation loop
                        if (bP1turn){
                            System.out.println("It is player 1's turn.");
                        }
                        else{
                            System.out.println("It is player 2's turn.");
                        }
                        System.out.print("Type your input here. Type \"help\" to view the help section:");
                        strInput = scn.nextLine();
                        // User input cleaning
                        strInput.toLowerCase(Locale.ROOT);
                        strInput.trim();
                        // User input testing
                        if (strInput.contains(",") && strInput.length() >= 8){
                            strSplit =  strInput.split(" ");
                            coordSplit = strSplit[1].split(",");
                            try{
                                intSplit[0] = Integer.parseInt(coordSplit[0]);
                                intSplit[1] = Integer.parseInt(coordSplit[1]);
                            }
                            catch (Exception e){
                                System.out.println("Input Error. Please try again.");
                                bInputValid = false;
                            }
                            //Check if the inputs are on the grid:
                            if ((intSplit[0] > 0 && intSplit[1] > 0)){
                                if (chDifficulty == 'B'){
                                    bCoordsValid = (intSplit[0] <= 3 && intSplit[1] <= 3);
                                }
                                else{
                                    if (chDifficulty == 'I'){
                                        bCoordsValid = (intSplit[0] <= 6 && intSplit[1] <= 6);
                                    }
                                    else{ // chDifficulty == 'A'
                                        bCoordsValid = (intSplit[0] <= 9 && intSplit[1] <= 9);
                                    }
                                }
                            }
                            else{
                                bCoordsValid = false;
                                bInputValid = false;
                            }

                            if (bCoordsValid){
                                //FIRE
                                if (strInput.contains("fire") && strInput.length() == 8){
                                    // The fire input needs exactly 8 characters
                                    // f i r e _ # , #
                                    // 1 2 3 4 5 6 7 8

                                    if (bP1turn) { // Player 1's turn
                                        //Player 1 fires at player 2's grid.
                                        strOutput = b1.fire(intSplit[0]-1, intSplit[1]-1, 2, 1, false);

                                    }
                                    else { // player 2's turn
                                        //Player 1 fires at player 2's grid.
                                        strOutput = b1.fire(intSplit[0]-1, intSplit[1]-1, 1, 2, false);
                                    }

                                    if (strOutput.contains("WIN")){
                                        if(bP1turn){
                                            bWinner = true; // P1 wins.
                                        }
                                        else{
                                            bWinner = false; //P2 wins.
                                        }
                                        bInputValid = true;
                                        bGameContinue = false;
                                    }
                                    else{
                                        if (strOutput.equals("INVALID COORDINATES")){
                                            System.out.println(strOutput);
                                            bInputValid = false;
                                        }
                                        else{
                                            if (strOutput.contains("MISS")){
                                                strOutput.replaceAll("MISS", "");
                                            }
                                            //Always print out the results of the fire command, regardless if it's a hit or a miss.
                                            //We've already verified that the shot is somewhere on the board.
                                            System.out.println(strOutput);
                                            if (bP1turn){
                                                turnCountP1 += 1;
                                            }
                                            else{
                                                turnCountP2 += 1;
                                            }
                                            bInputValid = true;
                                        }
                                    }
                                }
                                else{
                                    //MISSILE
                                    if (strInput.contains("missile") && strInput.length() == 11){
                                        // The missile input needs at least 11 characters
                                        // m i s s i l e _ # ,  #
                                        // 1 2 3 4 5 6 7 8 9 10 11

                                        if (bP1turn) {
                                            strOutput = b1.missile(intSplit[0]-1, intSplit[1]-1, 1, 2);
                                        }
                                        else{
                                            strOutput = b1.missile(intSplit[0]-1, intSplit[1]-1, 2, 1);
                                        }

                                        if (strOutput.contains("WIN")){
                                            if(bP1turn){
                                                turnCountP1 += 1;
                                                bWinner = true; // P1 wins.
                                            }
                                            else{
                                                turnCountP2 += 1;
                                                bWinner = false; //P2 wins.
                                            }
                                            bInputValid = true;
                                            bGameContinue = false;
                                            System.out.println(strOutput);
                                        }
                                        else{
                                            if (strOutput.equals("No more power points remaining. Cannot fire missile.")){
                                                System.out.println(strOutput);
                                                bInputValid = false;
                                                // Do not increment turn count.
                                            }
                                            else{ // Other message returned. Missile deployment successful
                                                System.out.println(strOutput);
                                                bInputValid = true;
                                                if (bP1turn){
                                                    turnCountP1 += 1;
                                                }
                                                else{
                                                    turnCountP2 += 1;
                                                }
                                            }
                                        }
                                    }
                                    else{
                                        //SUBMARINE
                                        if (strInput.contains("submarine") && strInput.length() == 13){
                                            // The submarine input needs at least 13 characters
                                            // s u b m a r i n e _  #  ,  #
                                            // 1 2 3 4 5 6 7 8 9 10 11 12 13

                                            if (bP1turn) {
                                                strOutput = b1.submarine(intSplit[0]-1, intSplit[1]-1, 1, 2);
                                            }
                                            else{
                                                strOutput = b1.submarine(intSplit[0]-1, intSplit[1]-1, 2, 1);
                                            }

                                            if (strOutput.contains("WIN")){
                                                System.out.println(strOutput); // print the Submarine's message.

                                                turnCountTotal += 1; // increment turn count
                                                bInputValid = true;
                                                bGameContinue = false;
                                            }
                                            else{
                                                if (strOutput.equals("Submarine deployment failed. Player 1 does not have enough PP to deploy a submarine.")){
                                                    System.out.println(strOutput);
                                                    bInputValid = false;
                                                }
                                                else{ // other submarine message
                                                    System.out.println(strOutput);
                                                    bInputValid = true;
                                                }
                                            }

                                        }
                                        else{ //invalid input
                                            System.out.println("Error: Invalid input. Please try again.");
                                            bInputValid = false;
                                        }
                                    }
                                }
                            }
                            else{ // bCoordsValid == false
                                System.out.println("Error: Invalid Coordinates.");
                                bInputValid = false;
                                break; // break out of if-statement.
                            }
                        }
                        else{ // input does not contain a comma
                            if (strInput.equals("drone")){
                                bInputValid = true;
                                if (bP1turn) {
                                    strOutput = b1.drone(1, 2);
                                    turnCountP1 += 1;
                                }
                                else{
                                    strOutput = b1.drone(2, 1);
                                    turnCountP2 += 1;
                                }
                                System.out.println(strOutput);
                            }
                            else{
                                if (strInput.equals("help")){
                                    bInputValid = false; // loop through and re-print the board without incrementing the turns.
                                    Help(chMode, chDifficulty);
                                }
                                else{ //invalid input
                                    bInputValid = false;
                                    System.out.println("Error: Invalid input. Please try again.");
                                }
                            }
                        }
                    }

                    // Flip the value of bP1turn to alternate to the next player's turn.
                    if (bP1turn) { // End of player 1's turn.
                        bP1turn = false;
                        if (bGameContinue) {
                            System.out.println("It is now the end of Player 1's turn.");
                            System.out.println("Please turn the screen to player 2 and look away from the screen for the duration if their turn." +
                                    "\nPress enter to continue..");
                        }
                        else {
                            // Determine which player won and print "congratulations player x"
                        }
                        strInput = scn.nextLine();
                    }
                    else { // End of player 2's turn.
                        bP1turn = true;
                        if (bGameContinue) {
                            System.out.println("It is now the end of Player 2's turn.");
                            System.out.println("Please turn the screen to player 1 and look away from the screen for the duration if their turn." +
                            "\nPress enter to continue..");
                        }
                        else {
                            // Determine which player won and print "congratulations player x"
                        }
                        strInput = scn.nextLine();
                    }
                }
                // END GAME SEQUENCE - Multiplayer
                System.out.println("Total Turns: " + turnCountTotal);
                System.out.println("Thank you for playing! Goodbye.");
            }
        }
    }
}
