import org.jetbrains.annotations.NotNull;

import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

public class Board {
    private int nrows;
    private int ncols;

    private Cell[][] boardP1;
    private Cell[][] boardP1hidden;
    private Cell[][] boardP2;
    private Cell[][] boardP2hidden;

    private Boat[] boatArray;
    private Boat[] boatArrayP2;

    private int boatsRemainingP1;
    private int boatsRemainingP2;

    private int powerPointsRemainingP1;
    private int powerPointsRemainingP2;

    private String DroneScannedRowsP1 = "";
    private String DroneScannedColsP1 = "";
    private String DroneScannedRowsP2 = "";
    private String DroneScannedColsP2 = "";
    private boolean playermode; // true = singleplayer, false = multiplayer

    public Board(char difficulty, char mode){
        mode = Character.toUpperCase(mode);

        if (mode == 'S') // Single player. P1 variables only.
        {
            this.playermode = true;
            difficulty = Character.toUpperCase(difficulty);
            switch(difficulty){
                case 'I': // Intermediate. 6x6 board
                    this.boatsRemainingP1 = 3;
                    this.powerPointsRemainingP1 = 3;
                    this.ncols = 6;
                    this.nrows = 6;
                    break;

                case 'A': // Advanced. 9x9 board
                    this.boatsRemainingP1 = 5;
                    this.powerPointsRemainingP1 = 5;
                    this.ncols = 9;
                    this.nrows = 9;
                    break;

                default: // Default to Beginner. 3x3 board
                case 'B':
                    this.boatsRemainingP1 = 1;
                    this.powerPointsRemainingP1 = 1;
                    this.ncols = 3;
                    this.nrows = 3;
                    break;
            }
            // Set up new board.
            boardP1 = new Cell[this.ncols][this.nrows];

            // Set up the boats.
            this.boardP1 = placeBoats(this.ncols, this.nrows, 1);
        }

        // Two players. P1 and P2 variables used. AI might be implemented.
        else{
            if (mode == 'T') {
                this.playermode = false;
                difficulty = Character.toUpperCase(difficulty);
                switch(difficulty){
                    case 'I': // Intermediate. 6x6 board
                        this.boatsRemainingP1 = 3;
                        this.powerPointsRemainingP1 = 3;
                        this.boatsRemainingP2 = 3;
                        this.powerPointsRemainingP2 = 3;
                        this.ncols = 6;
                        this.nrows = 6;
                        break;

                    case 'A': // Advanced. 9x9 board
                        this.boatsRemainingP1 = 5;
                        this.powerPointsRemainingP1 = 5;
                        this.boatsRemainingP2 = 5;
                        this.powerPointsRemainingP2 = 5;
                        this.ncols = 9;
                        this.nrows = 9;
                        break;

                    default: // Default to Beginner. 3x3 board
                    case 'B':
                        this.boatsRemainingP1 = 1;
                        this.powerPointsRemainingP1 = 1;
                        this.boatsRemainingP2 = 1;
                        this.powerPointsRemainingP2 = 1;
                        this.ncols = 3;
                        this.nrows = 3;
                        break;
                }
                // Set up new board.
                boardP1 = new Cell[this.ncols][this.nrows];
                boardP2 = new Cell[this.ncols][this.nrows];

                // Set up the boats.
                this.boardP1 = placeBoats(this.ncols, this.nrows, 1);
                this.boardP2 = placeBoats(this.ncols, this.nrows, 2);
            }
            else{
                System.out.println("ERROR: invalid input for singleplayer/multiplayer mode.");
            }
        }
    }

    public Cell[][] placeBoats(int cols, int rows, int player){
        // Always Assume the 2D array always has the same number of columns as rows.
        Cell[][] cellBoard = new Cell[cols][rows]; // 2D cell array to be returned.

        // Set up cell grid on cellBoard[][].
        for (int a = 0; a < cols; a++){
            for (int b = 0; b < rows; b++){
                cellBoard[a][b] = new Cell(a, b, '-'); // set up empty cells.
            }
        }

        if (player == 1){
            if (rows == 3){
                // If it's a 3x3 grid, then there is only one boat: One 2-cell Destroyer.
                // Since we are only making one boat here, we don't need to check for overlapping ships.
                // Set up the boat array.
                this.boatArray = new Boat[1]; // Only one boat here.
                cellBoard = getRandomBoatConfig("destroyer", 0, 2, cellBoard, 1);
            }
            else{ // More than 3 rows
                if (rows == 6){
                    // If it's a 6x6 grid, then there are three ships: One 2-cell Destroyer, one 3-cell Cruiser, and one 4-cell Battleship.
                    // Set up the boat array.
                    this.boatArray = new Boat[3];
                    cellBoard = getRandomBoatConfig("destroyer", 0, 2, cellBoard, 1);
                    cellBoard = getRandomBoatConfig("cruiser", 1, 3, cellBoard,1 );
                    cellBoard = getRandomBoatConfig("battleship", 2, 4, cellBoard ,1);
                }
                else{
                    if (rows == 9){
                        // One 2-cell Destroyer. two 3-cell Cruisers, one 4-cell Battleship and one 5-cell Carrier.
                        // Set up the boat array.
                        this.boatArray = new Boat[5];
                        cellBoard = getRandomBoatConfig("destroyer", 0, 2, cellBoard, 1);
                        cellBoard = getRandomBoatConfig("cruiser", 1, 3, cellBoard, 1);
                        cellBoard = getRandomBoatConfig("cruiser", 2, 3, cellBoard, 1);
                        cellBoard = getRandomBoatConfig("battleship", 3, 4, cellBoard, 1);
                        cellBoard = getRandomBoatConfig("carrier", 4, 5, cellBoard, 1);
                    }
                    else{
                        System.out.println("ERROR: Invalid input for board size in placeBoats.");
                    }
                }
            }
        }
        else{ // player == 2
            if (rows == 3){
                // If it's a 3x3 grid, then there is only one boat: One 2-cell Destroyer.
                // Since we are only making one boat here, we don't need to check for overlapping ships.
                // Set up the boat array.
                this.boatArrayP2 = new Boat[1]; // Only one boat here.
                cellBoard = getRandomBoatConfig("destroyer", 1, 2, cellBoard, 2);
            }
            else{ // More than 3 rows
                if (rows == 6){
                    // If it's a 6x6 grid, then there are three ships: One 2-cell Destroyer, one 3-cell Cruiser, and one 4-cell Battleship.
                    // Set up the boat array.
                    this.boatArrayP2 = new Boat[3];
                    cellBoard = getRandomBoatConfig("destroyer", 0, 2, cellBoard, 2);
                    cellBoard = getRandomBoatConfig("cruiser", 1, 3, cellBoard, 2);
                    cellBoard = getRandomBoatConfig("battleship", 2, 4, cellBoard, 2);
                }
                else{
                    if (rows == 9){
                        // One 2-cell Destroyer. two 3-cell Cruisers, one 4-cell Battleship and one 5-cell Carrier.
                        // Set up the boat array.
                        this.boatArrayP2 = new Boat[5];
                        cellBoard = getRandomBoatConfig("destroyer", 0, 2, cellBoard, 2);
                        cellBoard = getRandomBoatConfig("cruiser", 1, 3, cellBoard, 2);
                        cellBoard = getRandomBoatConfig("cruiser", 2, 3, cellBoard, 2);
                        cellBoard = getRandomBoatConfig("battleship", 3, 4, cellBoard, 2);
                        cellBoard = getRandomBoatConfig("carrier", 4, 5, cellBoard, 2);
                    }
                    else{
                        System.out.println("ERROR: Invalid input for board size in placeBoats.");
                    }
                }
            }
        }
        return cellBoard;
    }

    public Cell[][] getRandomBoatConfig(String type, int intBoatIndex, int boatSize, Cell[][] cellB, int player) {
        // getRandomBoatConfig takes in the current 2D cell array along with a new boat, and finds a space for the new boat on the board.
        // This is made to override the current 2D cell array of either boatArray or boatArrayP2, depending on what it's assigned-to from the outside.
        int boardSize = cellB.length;
        int intRightSideX = boardSize - 1;
        int intBottomSideY = intRightSideX;
        int intRandOri = '0';
        char randOri = 'h';
        int maxX = 0;
        int maxY = 0;
        int randX = 0;
        int randY = 0;
        // TODO: Determine correct intOffset for boats.
        int intOffset = boatSize - 1; // The offset of the boat from the edge of the grid is always minus 1(?)
        boolean bFitFound = false;

        intOffset = boatSize - 1;

        while (!bFitFound) { // This will keep retrying until it finds a fitting spot for the new boat.
            // The board sizes are large enough such that infinite loops shouldn't ever happen here.

            //intRandOri randomly chooses a horizontal or vertical orientation for the new boat.
            intRandOri = getRandomNumber(0,1); // 0 = 'h' (horizontal), 1 = 'v' (vertical)
            switch(intRandOri){
                case 1:
                    randOri = 'v';
                    maxX = intRightSideX;
                    maxY = intBottomSideY - intOffset;
                    break;

                default:
                    randOri = 'h';
                    maxX = intRightSideX - intOffset;
                    maxY = intBottomSideY;
            }
            randX = getRandomNumber(0, maxX-1);
            randY = getRandomNumber(0, maxY-1);

            bFitFound = CheckEmpty(randX, randY, boatSize, randOri, cellB);
        }
        // At this point, a fit was found. Now put everything together and return the new 2D cell array.

        if (player == 1){
            if (randOri == 'h') {
                for (int i = 0; i < boatSize; i++) {
                    cellB[randX + i][randY].setStatus('B');
                }
            }
            else{ // randOri == 'v'
                for (int i = 0; i < boatSize; i++) {
                    cellB[randX][randY + i].setStatus('B');
                }
            }
            this.boatArray[intBoatIndex] = new Boat(type, randX, randY, randOri, intBoatIndex);
        }
        else{ // player == 2
            if (randOri == 'h') {
                for (int i = 0; i < boatSize; i++) {
                    cellB[randX + i][randY].setStatus('B');
                }
            }
            else{ // randOri == 'v'
                for (int i = 0; i < boatSize; i++) {
                    cellB[randX][randY + i].setStatus('B');
                }
            }
            this.boatArrayP2[intBoatIndex] = new Boat(type, randX, randY, randOri, intBoatIndex);
        }

        return cellB;
    }

    public boolean CheckEmpty(int X, int Y, int size, char randOri, Cell[][] cellC){
        // Checks if enough cells are empty for a boat to fit across them
        boolean bBoatFound = false;
        if (randOri == 'h'){
            // Horizontal boat.
            // First, check if all the cells this boat needs in the horizontal direction are empty.
            // If cells in the horizontal direction are not empty, try a different orientation.
            // If cells in the other orientation are not empty, try a different coordinate.

            try{
                for (int x = 0; x < size; x++) {
                    if (cellC[X + x][Y].get_status() == 'B'){
                        bBoatFound = true;
                    }
                }
            }
            catch (ArrayIndexOutOfBoundsException e){
                String shutup = e.toString();
                bBoatFound = true;
                // If the emptiness checker (somehow) goes off the grid in the search for empty cells, just have the program
                // act like it found a boat there, and make the program search for a different spot to put the boat.
                // The intOffset variable from the PlaceBoats method SHOULD be enough to ensure that this never happens, but
                // just in case, this exception catch is in place.
            }
        }
        else{
            // Vertical boat
            try{
                for (int y = 0; y < size; y++) {
                    if (cellC[X][Y + y].get_status() == 'B'){
                        bBoatFound = true;
                    }
                }
            }
            catch (ArrayIndexOutOfBoundsException e){
                String shutup = e.toString();
                bBoatFound = true;
                // If the emptiness checker (somehow) goes off the grid in the search for empty cells, just have the program
                // act like it found a boat there, and make the program search for a different spot to put the boat.
                // The intOffset variable from the PlaceBoats method SHOULD be enough to ensure that this never happens, but
                // just in case, this exception catch is in place.
            }
        }
        return !bBoatFound;
    }

    public int getRandomNumber(int min, int max) {
        // Returns a random number between min and max.
        // Source: https://stackoverflow.com/questions/363681/how-do-i-generate-random-integers-within-a-specific-range-in-java

        return ThreadLocalRandom.current().nextInt(min, max+1);
    }

    public String fire(int x, int y, int targetPlayer, int shooter,boolean bHideMisses){
        Boat targetHit;
        int health;
        String sunkenShipIn = "";
        String sunkenShipOut = "";
        String toReturn = "";
        if (x <= this.ncols && y <= this.nrows){
            switch(targetPlayer){
                case 1:
                    switch(this.boardP1[x][y].get_status()){
                        case 'B': //A boat exists in the space! This is what the player wants.
                            targetHit = this.getBoatAtCoords(x, y, 1);
                            if (targetHit != null){
                                toReturn = RandomHitMessage();
                                toReturn += "\nYou hit a " + targetHit.getType() + "!";
                                this.boardP1[x][y].setStatus('H');
                                health = targetHit.getHealth();
                                targetHit.setHealth(health - 1);
                                if (health - 1 == 0){
                                    sunkenShipIn = targetHit.getType();
                                    sunkenShipOut = sunkenShipIn.substring(0,1).toUpperCase(Locale.ROOT) + sunkenShipIn.substring(1);
                                    toReturn += "\nYou've sunk an enemy " + sunkenShipOut + "!";
                                    this.boatsRemainingP1 -= 1;
                                    if (this.boatsRemainingP1 == 0){
                                        toReturn += "\nThere are no enemy ships remaining. YOU WIN!";
                                    }
                                    else{
                                        toReturn += "\nThere are " + this.boatsRemainingP1 + " enemy ships remaining...";
                                    }
                                }
                            }
                            else{
                                toReturn = "INVALID SHIP";
                            }
                            break;

                        case '-':
                            if (!bHideMisses){
                                toReturn += RandomMissMessage();
                                toReturn += "MISS";
                            }
                            this.boardP1[x][y].setStatus('M');
                            break;

                        case 'H':
                            toReturn += "You've already hit that part of that ship. It can't get any more destroyed!";
                            targetHit = this.getBoatAtCoords(x, y, 1);
                            toReturn += "\nSounds like you hit a " + targetHit.getType() + "...";
                            //toReturn = "ALREADY HIT";
                            break;

                        case 'M':
                            toReturn += "\nYou've already tried shooting that spot before, and you missed! Don't remember? Too bad!";
                           // toReturn = "ALREADY MISSED";
                            break;
                    }
                    break;

                case 2:
                    switch(this.boardP2[x][y].get_status()){
                        case 'B':
                            System.out.println(RandomHitMessage());
                            this.boardP2[x][y].setStatus('H');
                            targetHit = this.getBoatAtCoords(x, y, 2);
                            if (targetHit != null){
                                health = targetHit.getHealth();
                                targetHit.setHealth(health - 1);
                                toReturn += "\nYou hit an enemy " + targetHit.getType() + "!\n";
                                if (health - 1 == 0){
                                    sunkenShipIn = targetHit.getType();
                                    sunkenShipOut = sunkenShipIn.substring(0,1).toUpperCase(Locale.ROOT) + sunkenShipIn.substring(1);
                                    toReturn += "You've sunk an enemy " + sunkenShipOut + "!";
                                    this.boatsRemainingP2 -= 1;
                                    if (this.boatsRemainingP2 == 0){
                                        toReturn += "There are no enemy ships remaining. YOU WIN!";
                                        toReturn = "WIN";
                                    }
                                    else{
                                        toReturn += "There are " + this.boatsRemainingP2 + " enemy boats remaining...";
                                        toReturn = "SINK";
                                    }
                                }
                                else{
                                    toReturn = "HIT";
                                }
                            }
                            else{
                                toReturn = "INVALID SHIP";
                            }
                            break;

                        case '-':
                            if (!bHideMisses){
                                System.out.println(RandomMissMessage());
                            }
                            this.boardP2[x][y].setStatus('M');
                            toReturn += "\nMISS";
                            break;

                        case 'H':
                            targetHit = this.getBoatAtCoords(x, y, 2);
                            if (!bHideMisses){
                                toReturn += "You've already hit that part of that ship. It can't get any more destroyed!";
                                toReturn += "...Sounds like you hit a " + targetHit.getType() + "...";
                                toReturn = "ALREADY HIT";
                            }
                            break;

                        case 'M':
                            toReturn += "You've already tried shooting that spot before, and you missed! Don't remember? Too bad!";
                            toReturn = "ALREADY MISSED";
                            break;
                    }
                    break;

                default:
                    toReturn = "INVALID PLAYER";
                    break;
            }
        }
        else{
            if (!bHideMisses){
                System.out.println("Error: Where are you aiming? Those coordinates are off the map!");
            }
            toReturn = "INVALID COORDINATES";
        }
        return toReturn;
    }

    public String RandomMissMessage(){
        //Display a random miss message. Variety is the spice of life.
        int random = getRandomNumber(1, 10);
        String message = "";
        switch(random){
            case 1:
                message = "\nIt's a miss.\n";
                break;
            case 2:
                message = "\nYou hit some dirty whale poachers! Too bad they don't count...\n";
                break;
            case 3:
                message = "\nSploosh.\n";
                break;
            case 4:
                message = "\nNothing but ocean...\n";
                break;
            case 5:
                message = "\nMiss!\n";
                break;
            case 6:
                message = "\nb r i c k\n";
                break;
            case 7:
                message = "\nwhoosh\n";
                break;
            case 8:
                message = "\nMethinks the cannon's busted!\n";
                break;
            case 9:
                message = "\nSome wind pushed the projectile off-course!\n";
                break;
            case 10:
                message = "\nIt's a Miss! Darn this lazy eye.\n";
                break;
            default:
                message = "\nYou missed.\n";
        }
        return message;
    }

    public String RandomHitMessage(){
        // Display a random hit message. Variety is the spice of life.
        // Hit messages are always shown.
        int rando = getRandomNumber(1, 10);
        String message = "";
        switch(rando){
            case 1:
                message = "\nIT'S A HIT!!\n";
                break;

            case 2:
                message = "\nBOOM! Nice shot!\n";
                break;

            case 3:
                message = "\n[[EXPLOSIONS!]]\n";
                break;

            case 4:
                message = "\nULTRA KILL!\n";
                break;

            case 5:
                message = "**OH THE HUMANITY!**\n";
                break;

            case 6:
                message = "\nNailed it!\n";
                break;

            case 7:
                message = "\nBULLSEYE!\n";
                break;

            case 8:
                message = "\n**METAL CRUNCHING INTENSIFIES**\n";
                break;

            case 9:
                message = "\nHEADSHOT!\n";
                break;

            case 10:
                message = "\nRight between the eyes!\n";
                break;

                default:
                    message = "\nGood Shot!\n";
                    break;
        }
        return message;
    }

    public String sink(Boat toSink, int sinkingplayer, boolean bShowMessages){
        //Sinks a player's boat
        char TBOri = toSink.getOrientation();
        int TBSize = toSink.getSize();
        int TBbowX = toSink.getXpos();
        int TBbowY = toSink.getYpos();
        String sunkenShipIn = toSink.getType();
        String sunkenShipOut = "";

        for (int i = 0; i < TBSize; i++){
            if (TBOri == 'h'){
                if (sinkingplayer == 1){
                    this.boardP1[TBbowX+i][TBbowY].setStatus('H');
                }
                else{ // sinkingplayer == 2
                    this.boardP2[TBbowX+i][TBbowY].setStatus('H');
                }
            }
            else{ //TBOri == 'v'
                if (sinkingplayer == 1){
                    this.boardP1[TBbowX][TBbowY+i].setStatus('H');
                }
                else{ // sinkingplayer == 2
                    this.boardP2[TBbowX][TBbowY+i].setStatus('H');
                }
            }
        }
        switch(sinkingplayer){
            case 2:
                this.boatsRemainingP2 -= 1;
                break;

            default: //P1
                this.boatsRemainingP1 -= 1;
                break;
        }
        toSink.setHealth(0);
        sunkenShipOut = sunkenShipIn.substring(0,1).toUpperCase(Locale.ROOT) + sunkenShipIn.substring(1);
        String strReturn = "";
        if (bShowMessages){
            strReturn = "You've sunk an enemy " + sunkenShipOut + "!";
            if (this.boatsRemainingP1 == 0){
                strReturn ="All of Player 1's ships have been sunk. Congratulations, you WIN!";
            }
            else{
                if (this.boatsRemainingP2 == 0){
                    strReturn ="All of Player 2's ships have been sunk. Congratulations, you WIN!";
                }
            }
        }
        return strReturn;
    }

    public Boat getBoatAtCoords(int x, int y, int player){
        // Checks if there is a boat at the given coordinates, and returns that boat's data if it exists.
        boolean boatFound = false;
        int boatIndex = 0;

        // Check if the coordinates are even on the board.
        if (x <= this.ncols-1 && y <= this.nrows-1){
            if (player == 1){
                // Check if a boat exists at the specified coordinates
                if (this.boardP1[x][y].get_status() == 'B' || this.boardP1[x][y].get_status() == 'H'){
                    // Go through boatArray and find which boat has these coordinates.
                    for (int i = 0; i < this.boatArray.length; i++){
                        if (this.boatArray[i].containsCoordinates(x, y)){
                            boatFound = true;
                            boatIndex = i;
                        }
                    }
                    if (boatFound){
                        return this.boatArray[boatIndex];
                    }
                    else{ // no boat found at coordinates.
                        //System.out.println("ERROR: No boat found at coordinates X: " + x + ", Y: " + y);
                        return null;
                    }
                }
                else{ // no boat at location.
                    return null;
                }
            }
            else{ // player == 2
                // Check if a boat exists at the specified coordinates
                if (this.boardP2[x][y].get_status() == 'B' || this.boardP2[x][y].get_status() == 'H'){
                    // Go through boatArray and check which boat has these coordinates.
                    for (int i = 0; i < this.boatArrayP2.length; i++){
                        if (this.boatArrayP2[i].containsCoordinates(x, y)){
                            boatFound = true;
                            boatIndex = i;
                        }
                    }
                    if (boatFound){
                        return this.boatArrayP2[boatIndex];
                    }
                    else{ // no boat found at coordinates.
                        //System.out.println("ERROR: No boat found at coordinates X: " + x + ", Y: " + y);
                        return null;
                    }
                }
                else{ // no boat at location.
                    return null;
                }
            }
        }
        else{
            // Coordinates are off the board.
            return null;
        }
    }

    public String display(int player, boolean bHideHUD){
        // The display method is for the special "debug" mode.
        // Display doesn't use the boardP#hidden 2D arrays, it just makes a string out of the bare boardP# 2D arrays and returns that.
        String result = "";
        char status;

        if (player == 1){
            for (int y = 0; y < this.nrows; y++) {
                for (int x = 0; x < this.ncols; x++) {
                    result += String.valueOf(this.boardP1[x][y].get_status()) + " ";
                    if (x+1 == this.ncols){
                        result += ("< " + (y+1) + "\n"); // set up the row counter numbers on the side of the board
                    }
                }
            }
        }
        else{
            if (player == 2){
                for (int y = 0; y < this.nrows; y++) {
                    for (int x = 0; x < this.ncols; x++) {
                        result += String.valueOf(this.boardP2[x][y].get_status()) + " ";
                        if (x+1 == this.ncols){
                            result += ("< " + (y+1) + "\n"); // set up the row counter numbers on the side of the board
                        }
                    }
                }
            }
            else{
                return "Error: Invalid input for player in display method.";
            }
        }
        // Set up the column counter numbers on the bottom of the board.
        switch(this.ncols){
            case 3:
                result += "^ ^ ^ \n1 2 3 ";
                break;

            case 6:
                result += "^ ^ ^ ^ ^ ^ \n1 2 3 4 5 6 ";
                break;

            default: // 9
                result += "^ ^ ^ ^ ^ ^ ^ ^ ^ \n1 2 3 4 5 6 7 8 9 \n";
                break;
        }

        // Update and show HUD, if it isn't set to be hidden.
        if (!bHideHUD){
            if(player == 1){
                result += ("PP: " + this.powerPointsRemainingP1);
                if (this.playermode) { //if playermode is singleplayer
                    result += (" | Enemy Ships Remaining: " +  this.boatsRemainingP1);
                }
                else{ // multiplayer
                    result += (" | Enemy Ships Remaining: " +  this.boatsRemainingP2 + " | Your ships remaining: " + this.boatsRemainingP1);
                }
            }
            else{ // player == 2
                // If player 2 exists, then the mode is always multiplayer.
                result += ("PP: " + this.powerPointsRemainingP2 + " | Enemy Ships Remaining: " +  this.boatsRemainingP1 + " | Your ships remaining: " + this.boatsRemainingP2);
            }
        }
        return result;
    }

    public String print(int player, boolean bHideHUD){
        // This is the normal gameboard display mode, with all the unhit boats hidden.
        // Make a cover board over the real board.
        // Make sure to overwrite the correct player's boardP#hidden Cell[][] array.
        char status;
        String result = "";

        if (player == 1){
            // Set up and initialize the P1 board.
            this.boardP1hidden = new Cell[this.ncols][this.nrows];
            // Set up cells
            for (int y = 0; y < this.nrows; y++){
                for (int x = 0; x < this.ncols; x++){
                    status = this.boardP1[x][y].get_status();
                    this.boardP1hidden[x][y] = new Cell(x, y, CellPrintStatusChecker(status));
                    result += (String.valueOf(this.boardP1hidden[x][y].get_status()) + " ");
                    if (x+1 == this.ncols){
                        result += ("< " + (y+1) + "\n"); // set up the row counter numbers on the side of the board
                    }
                }
            }
        }
        else{
            if(player == 2){
                // Set up and initialize the P2 board.
                this.boardP2hidden = new Cell[this.ncols][this.nrows];
                // Set up cells
                for (int y = 0; y < this.nrows; y++){
                    for (int x = 0; x < this.ncols; x++){
                        status = this.boardP2[x][y].get_status();
                        this.boardP2hidden[x][y] = new Cell(x, y, CellPrintStatusChecker(status));
                        result += (String.valueOf(this.boardP2hidden[x][y].get_status()) + " ");
                        if (x+1 == this.ncols){
                            result += ("< " + (y+1) + "\n"); // set up the row counter numbers on the side of the board
                        }
                    }
                }
            }
            else{
                System.out.println("ERROR: Invalid input for player in display method.");
            }
        }
        // Set up the column counter numbers on the bottom of the board.
        switch(this.ncols){
            case 3:
                result += "^ ^ ^ \n1 2 3 \n";
                break;

            case 6:
                result += "^ ^ ^ ^ ^ ^ \n1 2 3 4 5 6 \n";
                break;

            default: // 9
                result += "^ ^ ^ ^ ^ ^ ^ ^ ^ \n1 2 3 4 5 6 7 8 9 \n";
                break;
        }

        // Update and show HUD, if it isn't set to be hidden.
        if (!bHideHUD){
            if(player == 1){
                result += ("PP: " + this.powerPointsRemainingP1);
                if (this.playermode) { //if playermode is singleplayer
                    result += (" | Enemy Ships Remaining: " +  this.boatsRemainingP1);
                }
                else{ // multiplayer
                    result += (" | Enemy Ships Remaining: " +  this.boatsRemainingP2 + " | Your ships remaining: " + this.boatsRemainingP1);
                }
            }
            else{ // player == 2
                // If player 2 exists, then the mode is always multiplayer.
                result += ("PP: " + this.powerPointsRemainingP2 + " | Enemy Ships Remaining: " +  this.boatsRemainingP1 + " | Your ships remaining: " + this.boatsRemainingP2);
            }
        }

        return result;
    }

    private char CellPrintStatusChecker(char c){
        // Used for the normal "print" mode (not for debug: debug mode just shows everything uncovered)
        switch(c) {
            case 'H': // 'H' means a boat exists in the space, and it has been hit.
                return 'X'; // The 'X' char marks spaces where boats were hit.

            case 'M': // 'M' means no boat exists in the space, and the space has been shot at.
                return '0'; // The '0' char marks spaces where guesses missed.

            case 'b': // 'b' is a boat scanned by the drone power.
                return c;

            default: // for 'B' (boat exists on space; unguessed) or '-' (no boat exists; unguessed)
                return '~';
        }
    }

    public String missile(int x, int y, int shooter, int targetPlayer){
        /*
        "Missile" is an explosive power that "fires" at nine coordinates at and around the target coordinate:
        1 2 3
        4 5 6
        7 8 9

        ...where "5" is the target coordinate.
        If there is a 'B' char (an un-hit boat) in any of the coordinates, mark it as a hit and get the info.

        (x-1, y-1)  (x, y-1)    (x+1, y-1)
        (x-1, y)    (x, y)      (x+1, y)
        (x-1, y+1)  (x, y+1)    (x+1, y+1)
         */
        int HitCount = 0;
        int MissCount = 0;
        boolean bFireMissile = false;
        int PowerPtCost = 1; // Set the cost of the missile power (in power-points) here.

        // First, check if the coordinates are on the board
        if (x <= this.ncols-1 && y <= this.nrows-1){
            bFireMissile = true;
        }
        else{
            bFireMissile = false;
            return "Error: Input coordinates are not on the board. Missile not fired.";
        }

        if (shooter == 1){
            if (this.powerPointsRemainingP1 >= PowerPtCost){

                bFireMissile = true;
            }
            else{
                bFireMissile = false;
                return ("Missile firing sequence failed: Player 1 does not have " + PowerPtCost + " or more PP remaining to fire a missile.");
            }
        }
        else{
            if (shooter == 2){
                if (this.powerPointsRemainingP2 >= PowerPtCost){
                    powerPointsRemainingP2 -= PowerPtCost;
                    bFireMissile = true;
                }
                else{
                    bFireMissile = false;
                    return ("Missile firing sequence failed: Player 2 does not have " + PowerPtCost + " or more PP remaining to fire a missile.");
                }
            }
            else{
                bFireMissile = false;
                return "Error: invalid input for shooter.";
            }
        }

        if (bFireMissile){
            System.out.println("--| Firing missile! |--");
            //Deduct the power points.
            switch(shooter){
                case 1:
                    powerPointsRemainingP1 -= PowerPtCost;
                    break;

                default: //p2
                    powerPointsRemainingP2 -= PowerPtCost;
                    break;
            }

            // Fire on all 9 of the slots that are on the board.
            String strRes = "";
            boolean bWin = false;
            for (int yIter = y-1; yIter <= y+1; yIter++){
                for (int xIter = x-1; xIter <= x+1; xIter++){
                    if (xIter <= this.ncols-1 && yIter <= this.nrows-1){
                        strRes += fire(xIter, yIter, targetPlayer, shooter, true);
                        if (strRes.contains("WIN")){
                            bWin = true;
                        }
                        else{
                            if (strRes.contains("hit")){
                                HitCount++;
                            }
                            else{
                                MissCount++;
                            }
                        }
                    }
                }
            }
            if (bWin){
                return strRes;
            }
            else{
                return ("The missile hit " + HitCount + " times and missed " + MissCount + " times.");
            }
        }
        else{
            return "No more power points remaining. Cannot fire missile.";
        }
    }

    public String submarine(int x, int y, int shooter, int targetPlayer) {
        // Submarines instantly sink any boat they hit.

        int PowerPtCost = 1;
        Boat TargetBoat;
        boolean bDeploy = false;
        String toReturn = "";

        if (x <= this.ncols && y <= this.nrows) { // Check if the given coordinates are on the board.
            if (shooter == 1) {
                if (this.powerPointsRemainingP1 >= PowerPtCost) {
                    bDeploy = true;
                }
                else{
                    toReturn = "Submarine deployment failed. Player 1 does not have enough PP to deploy a submarine.";
                }
            }
            else{ // shooter == 2
                if (this.powerPointsRemainingP2 >= PowerPtCost) {
                    bDeploy = true;
                }
                else{
                    toReturn = "Submarine deployment failed. Player 2 does not have enough PP to deploy a submarine.";
                }
            }

            if (bDeploy){
                if (targetPlayer == 1) {
                    if (this.boardP1[x][y].get_status() == 'B' || this.boardP1[x][y].get_status() == 'H' ){
                        // Since we checked the existence of the boat on the board, we know getBoatAtCoords will never be null here.
                        TargetBoat = getBoatAtCoords(x, y, targetPlayer);
                        toReturn = "The sub's nuclear torpedo hit! You sunk an entire " + TargetBoat.getType() + " in one hit!\n";
                        toReturn += sink(TargetBoat, 1, false);
                    }
                    else {
                        toReturn = "The submarine's torpedo missed!";
                    }
                }
                else { //targetPlayer == 2
                    if (this.boardP2[x][y].get_status() == 'B' || this.boardP2[x][y].get_status() == 'H' ){
                        // Since we checked the existence of the boat on the board, we know getBoatAtCoords will never be null here.
                        TargetBoat = getBoatAtCoords(x, y, targetPlayer);
                        toReturn = "The sub's nuclear torpedo hit! You sunk an entire " + TargetBoat.getType() + " in one hit!\n";
                        toReturn += sink(TargetBoat, 2, false);
                    }
                    else {
                        toReturn = "The submarine's torpedo missed!";
                    }
                }
            }
        }
        else {
            toReturn = "Error: those coordinates are off the map!";
        }
        return toReturn;
    }

    public String drone(int shooter, int target){
        // The Drone power scans a random row or column for ships
        int DronePPCost = 1;
        boolean bDeploy = false;

        if(shooter == 1){
            if (this.powerPointsRemainingP1 >= DronePPCost){
                this.powerPointsRemainingP1 -= DronePPCost;
                bDeploy = true;
            }
            else{
                return ("Drone deployment sequence failed: Player 1 does not have " + DronePPCost + " or more PP remaining to deploy a drone.");
            }
        }
        else{
            if(shooter == 2){
                if (this.powerPointsRemainingP2 >= DronePPCost){
                    this.powerPointsRemainingP2 -= DronePPCost;
                    bDeploy = true;
                }
                else{
                    return ("Drone deployment sequence failed: Player 2 does not have " + DronePPCost + " or more PP remaining to deploy a drone.");
                }
            }
            else{
                return "Error: Invalid input for drone-deploying player.";
            }
        }

        //If the code reaches this part, it means that nothing went wrong in the PP validation.
        if (bDeploy){
            System.out.println("--| Deploying Spy Drone! |--");
            int coin = getRandomNumber(0,1); // 0 = search random row; 1 = search random column. Remember, the array goes [cols][rows].
            int boatCount = 0;

            if (coin == 0){
                // Searching random row
                int randRow = getRandomNumber(0, this.nrows-1);

                // Make sure the random row hasn't been searched already.
                if (shooter == 1){
                    if (this.DroneScannedRowsP1.length() > 0){
                        while (this.DroneScannedRowsP1.contains(Integer.toString(randRow))){
                            randRow = getRandomNumber(0, this.nrows-1);
                        }
                    }
                    this.DroneScannedRowsP1 += Integer.toString(randRow);
                }
                else{
                    if (shooter == 2){
                        if (this.DroneScannedRowsP2.length() > 0){
                            while (this.DroneScannedRowsP2.contains(Integer.toString(randRow))){
                                randRow = getRandomNumber(0, this.nrows-1);
                            }
                        }
                        this.DroneScannedRowsP2 += Integer.toString(randRow);
                    }
                    else{
                        return "Error: Invalid player input for Drone command.";
                    }
                }

                // Iterate through the columns of the random row.
                for (int i = 0; i < this.ncols; i++){
                    switch(target){
                        case 1:
                            if (boardP1[i][randRow].get_status() == 'B'){
                                boatCount++;
                            }
                            break;

                        case 2:
                            if (boardP2[i][randRow].get_status() == 'B'){
                                boatCount++;
                            }
                            break;
                    }
                }
                return ("DRONE REPORT: There is " + boatCount + " unhit enemy ship(s) in row " + (randRow+1) + ". Remember this!");
            }
            else{ // coin == 1
                // Searching random column
                int randCol = getRandomNumber(0, this.ncols-1);

                // Make sure the random column hasn't been searched already.
                if (shooter == 1){
                    if (this.DroneScannedColsP1.length() > 0){
                        while (this.DroneScannedColsP1.contains(Integer.toString(randCol))){
                            randCol = getRandomNumber(0, this.ncols-1);
                        }
                    }
                    this.DroneScannedColsP1 += Integer.toString(randCol);
                }
                else{
                    if (shooter == 2){
                        if (this.DroneScannedColsP2.length() > 0){
                            while (this.DroneScannedColsP2.contains(Integer.toString(randCol))){
                                randCol = getRandomNumber(0, this.ncols-1);
                            }
                        }
                        this.DroneScannedColsP2 += Integer.toString(randCol);
                    }
                    else{
                        return "Error: Invalid input for player for Drone command.";
                    }
                }

                // Iterate through the rows of the random column.
                for (int i = 0; i < this.nrows; i++){
                    switch(target){
                        case 1: // target: player 1.
                            if (this.boardP1[randCol][i].get_status() == 'B'){
                                boatCount++;
                                this.boardP1hidden[randCol][i].setStatus('b');
                            }
                            break;

                        case 2: // target: player 2.
                            if (this.boardP2[randCol][i].get_status() == 'B'){
                                boatCount++;
                                this.boardP2hidden[randCol][i].setStatus('b');
                            }
                            break;
                    }
                }
                return ("DRONE REPORT: There is " + boatCount + " unhit enemy ships in column " + (randCol+1) + ". Remember this!");
            }
        }
        else{
            return "Drone deployment failed.";
        }
    }
}